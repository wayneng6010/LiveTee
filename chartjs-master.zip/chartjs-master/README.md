# chartjs

This repository contains code to create charts using ChartJS version 1.x.

If you are interested in getting the latest code using version 2.x then check the latest repository
[Click here](https://github.com/yusufshakeel/chartjs2)

For tutorial notes
[Click here](https://www.dyclassroom.com/chartjs/getting-started)

YouTube playlist
[Click here](https://www.youtube.com/watch?v=DhHeF7LKsyc&list=PLG6ePePp5vvZLVjT5mgyxBpkbNBpuAwq9)
